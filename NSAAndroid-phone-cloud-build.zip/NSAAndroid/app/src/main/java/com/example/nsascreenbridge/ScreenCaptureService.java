package com.example.nsascreenbridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScreenCaptureService extends Service {
    private static final String CHANNEL = "nsa_screen_bridge";
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private TextRecognizer recognizer;
    private boolean processing = false;
    private long lastCaptureAt = 0;
    private String receiverUrl, bridgeKey;
    private int width, height, density;
    private final Pattern periodPattern = Pattern.compile("\\b[0-9]{10,30}\\b");
    private final Pattern numberPattern = Pattern.compile("(?<![0-9])([0-9])(?![0-9])");

    @Override public void onCreate() {
        super.onCreate(); createChannel();
        thread = new HandlerThread("nsa-ocr"); thread.start(); handler = new Handler(thread.getLooper());
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        if (Build.VERSION.SDK_INT >= 29) startForeground(71, notification("Screen capture active"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(71, notification("Screen capture active"));
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL,"Screen Bridge",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification(String msg) {
        if (Build.VERSION.SDK_INT >= 26) return new Notification.Builder(this,CHANNEL).setContentTitle("Numeric Trend Bridge").setContentText(msg).setSmallIcon(android.R.drawable.ic_menu_view).build();
        return new Notification.Builder(this).setContentTitle("Numeric Trend Bridge").setContentText(msg).setSmallIcon(android.R.drawable.ic_menu_view).build();
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getParcelableExtra("data") == null) { stopSelf(); return START_NOT_STICKY; }
        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent data = intent.getParcelableExtra("data");
        android.content.SharedPreferences p = getSharedPreferences("bridge", MODE_PRIVATE);
        receiverUrl = p.getString("url", ""); bridgeKey = p.getString("key", "");
        // Values are saved by the Activity preferences; read them from its preference file too.
        android.content.SharedPreferences a = getSharedPreferences(getPackageName()+"_preferences", MODE_PRIVATE);
        if (receiverUrl.isEmpty()) receiverUrl = a.getString("url", "");
        if (bridgeKey.isEmpty()) bridgeKey = a.getString("key", "");
        // Activity.getPreferences uses a generated activity-specific preference name; use explicit intent extras fallback.
        if (receiverUrl.isEmpty()) receiverUrl = intent.getStringExtra("url");
        if (bridgeKey.isEmpty()) bridgeKey = intent.getStringExtra("key");
        if (receiverUrl == null || bridgeKey == null || receiverUrl.isEmpty() || bridgeKey.isEmpty()) { stopSelf(); return START_NOT_STICKY; }
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE); wm.getDefaultDisplay().getRealMetrics(dm);
        width = dm.widthPixels; height = dm.heightPixels; density = dm.densityDpi;
        MediaProjectionManager m = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = m.getMediaProjection(resultCode, data);
        reader = ImageReader.newInstance(width,height, PixelFormat.RGBA_8888,2);
        display = projection.createVirtualDisplay("Numeric Trend Bridge",width,height,density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        reader.setOnImageAvailableListener(r -> processLatestFrame(),handler);
        return START_NOT_STICKY;
    }
    private void processLatestFrame() {
        long now = System.currentTimeMillis();
        if (processing || now-lastCaptureAt < 1200) { Image drop=reader.acquireLatestImage(); if(drop!=null)drop.close(); return; }
        Image image = reader.acquireLatestImage(); if (image == null) return;
        processing = true; lastCaptureAt = now;
        try {
            Image.Plane plane = image.getPlanes()[0]; ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
            int bitmapWidth = rowStride / pixelStride;
            Bitmap full = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buffer);
            Bitmap crop = Bitmap.createBitmap(full,0,0,Math.min(width,full.getWidth()),height);
            full.recycle(); image.close();
            InputImage input = InputImage.fromBitmap(crop,0);
            recognizer.process(input).addOnSuccessListener(text -> {
                try { handleRecognized(text,crop); } finally { crop.recycle(); processing=false; }
            }).addOnFailureListener(e -> { crop.recycle(); processing=false; });
        } catch (Exception e) { image.close(); processing=false; }
    }
    private static class Row {
        long period; int n; String size; String color;
        Row(long p,int n,String s,String c){period=p;this.n=n;size=s;color=c;}
    }
    private void handleRecognized(Text text, Bitmap bitmap) {
        Map<Integer,StringBuilder> rows = new HashMap<>();
        Map<Integer,List<Text.Line>> linesByY = new HashMap<>();
        for (Text.TextBlock block : text.getTextBlocks()) for (Text.Line line : block.getLines()) {
            if (line.getBoundingBox()==null) continue;
            int y = line.getBoundingBox().centerY()/40;
            linesByY.computeIfAbsent(y,k->new ArrayList<>()).add(line);
        }
        List<Row> found = new ArrayList<>();
        for (List<Text.Line> lines : linesByY.values()) {
            StringBuilder all = new StringBuilder();
            for (Text.Line l : lines) all.append(' ').append(l.getText());
            Matcher pm = periodPattern.matcher(all.toString()); if (!pm.find()) continue;
            long period; try { period=Long.parseLong(pm.group()); } catch(Exception ex){continue;}
            String s=all.toString().toLowerCase();
            String size = s.matches("(?s).*\\bbig\\b.*") ? "BIG" : (s.matches("(?s).*\\bsmall\\b.*") ? "SMALL" : "");
            if (size.isEmpty()) continue;
            // Locate the standalone result digit in the same horizontal row, excluding the period.
            int n=-1;
            for (Text.Line l : lines) {
                String lt=l.getText().trim();
                if (lt.matches("[0-9]") && l.getBoundingBox().centerX() > bitmap.getWidth()*0.30f && l.getBoundingBox().centerX() < bitmap.getWidth()*0.78f) { n=Integer.parseInt(lt); break; }
            }
            if (n<0) {
                Matcher nm=numberPattern.matcher(s.replace(pm.group()," "));
                while(nm.find()) { int candidate=Integer.parseInt(nm.group(1)); if ((candidate<=4 && size.equals("SMALL")) || (candidate>=5 && size.equals("BIG"))) { n=candidate; break; } }
            }
            if(n<0) continue;
            String color=sampleDotColor(bitmap, bitmap.getWidth()*0.89f, lines.get(0).getBoundingBox().centerY());
            // Validate the text's stated size against the user's rule before sending.
            String expected=n<=4?"SMALL":"BIG"; if(!expected.equals(size)) continue;
            found.add(new Row(period,n,size,color));
        }
        if(found.isEmpty()) return;
        found.sort(Comparator.comparingLong(r -> r.period));
        android.content.SharedPreferences prefs=getSharedPreferences("nsa_state",MODE_PRIVATE);
        long last=prefs.getLong("last_period",0L);
        if(last==0L){ long newest=found.get(found.size()-1).period; prefs.edit().putLong("last_period",newest).apply(); updateNotification("Baseline set. Waiting for a new record."); return; }
        for(Row row:found){
            if(row.period<=last) continue;
            try {
                boolean ok=postRow(row);
                if(ok){ last=row.period; prefs.edit().putLong("last_period",last).apply(); updateNotification("Synced record "+row.period+" • number "+row.n); }
                else { updateNotification("Sync failed; will retry on next screen scan"); break; }
            } catch(Exception e){ updateNotification("Network error; will retry on next screen scan"); break; }
        }
    }
    private String sampleDotColor(Bitmap b,float xFraction,int y) {
        int cx=Math.max(0,Math.min(b.getWidth()-1,(int)(b.getWidth()*xFraction)));
        int red=0,green=0,other=0;
        for(int y0=Math.max(0,y-8);y0<=Math.min(b.getHeight()-1,y+8);y0+=2) for(int x0=Math.max(0,cx-8);x0<=Math.min(b.getWidth()-1,cx+8);x0+=2){
            int c=b.getPixel(x0,y0),r=(c>>16)&255,g=(c>>8)&255,bl=c&255;
            if(r>150 && r>g*1.35 && r>bl*1.2)red++; else if(g>100 && g>r*1.15 && g>bl*1.05)green++;
        }
        if(red>=green*1.35 && red>=8)return "red"; if(green>=red*1.25 && green>=8)return "green"; return "unknown";
    }
    private boolean postRow(Row r) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(receiverUrl).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.setRequestProperty("X-NSA-Bridge-Key",bridgeKey);
        JSONObject body=new JSONObject(); body.put("period",String.valueOf(r.period)); body.put("n",r.n); body.put("color",r.color);
        byte[] bytes=body.toString().getBytes("UTF-8"); c.setFixedLengthStreamingMode(bytes.length);
        try(OutputStream os=c.getOutputStream()){os.write(bytes);}
        int code=c.getResponseCode(); c.disconnect(); return code>=200 && code<300;
    }
    private void updateNotification(String s){ if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(71,notification(s)); }
    @Override public void onDestroy(){ if(display!=null)display.release(); if(reader!=null)reader.close(); if(projection!=null)projection.stop(); if(recognizer!=null)recognizer.close(); if(thread!=null)thread.quitSafely(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){return null;}
}
