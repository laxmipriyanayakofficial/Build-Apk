package com.example.nsascreenbridge;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 901;
    EditText url, key;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff202938);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,28);
        TextView title = new TextView(this); title.setText("Numeric Trend Bridge"); title.setTextSize(24); root.addView(title);
        TextView note = new TextView(this); note.setText("Reads visible numeric history rows only after you approve Android screen capture. It sends only newly detected record IDs; existing history is not imported. This is a data-transfer utility, not a stock-market signal generator. Keep your bridge key private."); note.setPadding(0,16,0,16); root.addView(note);
        url = new EditText(this); url.setHint("Receiver URL (https://your-site/wp-json/nsa-mobile/v1/ingest)"); url.setSingleLine(false); url.setText(getPreferences(0).getString("url", "")); root.addView(url);
        key = new EditText(this); key.setHint("Bridge key"); key.setSingleLine(true); key.setInputType(129); key.setText(getPreferences(0).getString("key", "")); root.addView(key);
        Button start = new Button(this); start.setText("Allow screen capture & start"); root.addView(start);
        Button stop = new Button(this); stop.setText("Stop monitoring"); root.addView(stop);
        TextView status = new TextView(this); status.setText("Status: stopped"); status.setPadding(0,16,0,0); root.addView(status);
        setContentView(root);
        start.setOnClickListener(v -> {
            String u = url.getText().toString().trim(), k = key.getText().toString().trim();
            if (!u.startsWith("https://") || !u.endsWith("/ingest") || k.length() < 20) { Toast.makeText(this,"Enter the HTTPS receiver URL and bridge key from WordPress settings.",Toast.LENGTH_LONG).show(); return; }
            getPreferences(0).edit().putString("url",u).putString("key",k).apply();
            MediaProjectionManager m = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQUEST_CAPTURE);
        });
        stop.setOnClickListener(v -> { stopService(new Intent(this, ScreenCaptureService.class)); status.setText("Status: stopped"); });
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent s = new Intent(this, ScreenCaptureService.class); s.putExtra("resultCode",resultCode); s.putExtra("data",data); s.putExtra("url",url.getText().toString().trim()); s.putExtra("key",key.getText().toString().trim());
            startForegroundService(s); Toast.makeText(this,"Monitoring started. Keep the source data screen visible.",Toast.LENGTH_LONG).show();
        }
    }
}
